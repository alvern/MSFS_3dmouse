#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_ABOUTBOX                            103
#define IDM_ABOUT                               104
#define IDM_EXIT                                105
#define IDI_MY3DXGALILEOSENSORDEMO              107
#define IDI_SMALL                               108
#define IDC_MY3DXGALILEOSENSORDEMO              109
#define IDD_3DX_GALILEO_DIALOG                  129
#define IDC_SENSOR_VALUE_X                      1001
#define IDC_SENSOR_SLIDER_X                     1002
#define IDC_SENSOR_VALUE_Y                      1003
#define IDC_SENSOR_SLIDER_Y                     1004
#define IDC_SENSOR_VALUE_Z                      1005
#define IDC_SENSOR_SLIDER_Z                     1006
#define IDC_SENSOR_VALUE_A                      1007
#define IDC_SENSOR_SLIDER_A                     1008
#define IDC_SENSOR_VALUE_B                      1009
#define IDC_SENSOR_SLIDER_B                     1010
#define IDC_SENSOR_VALUE_C                      1011
#define IDC_SENSOR_SLIDER_C                     1012
#define IDS_APP_TITLE                           40000
